import socket,sys,threading,time
from tkinter import *
from PIL import ImageTk, Image
 
# ==== Scan Vars ====
ip_s = 1
ip_f = 10
log = []
ports = []
target = 'localhost'
 
# ==== Scanning Functions ====
def scanPort(target, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(4)
        c = s.connect_ex((target, port))
        if c == 0:
            m = ' Port %d \t is open ' % (port,)
            log.append(m)
            ports.append(port)
            listbox.insert("end", str(m))
            updateResult()
        s.close()
    except OSError: print('> Too many open sockets. Port ' + str(port))
    except:
        c.close()
        s.close()
        sys.exit()
    sys.exit()
     
def updateResult():
    rtext = " [ " + str(len(ports)) + " / " + str(ip_f) + " ] ~ " + str(target)
    L27.configure(text = rtext)
 
def startScan():
    global ports, log, target, ip_f
    clearScan()
    log = []
    ports = []
    # Get ports ranges from GUI
    ip_s = int(EntminPort.get())
    ip_f = int(EntmaxPort.get())
    # Start writing the log file
    log.append('> Port Scanner')
    log.append('='*14 + '\n')
    log.append(' Target:\t' + str(target))
     
    try:
        target = socket.gethostbyname(str(EntIP.get()))
        log.append(' IP Adr.:\t' + str(target))
        log.append(' Ports: \t[ ' + str(ip_s) + ' / ' + str(ip_f) + ' ]')
        log.append('\n')
        # Lets start scanning ports!
        while ip_s <= ip_f:
            try:
                scan = threading.Thread(target=scanPort, args=(target, ip_s))
                scan.setDaemon(True)
                scan.start()
            except: time.sleep(0.01)
            ip_s += 1
    except:
        m = '> Target ' + str(EntIP.get()) + ' not found.'
        log.append(m)
        listbox.insert(0, str(m))
         
def saveScan():
    global log, target, ports, ip_f
    log[5] = " Result:\t[ " + str(len(ports)) + " / " + str(ip_f) + " ]\n"
    with open('portscan-'+str(target)+'.txt', mode='wt', encoding='utf-8') as myfile:
        myfile.write('\n'.join(log))

def delete():
   listbox.delete(0,END)

def clearScan():
    listbox.delete(0, 'end')
 
# ==== GUI ====
gui = Tk()
gui.title('Port Scanner')
gui.geometry("600x600+20+20")
 
# ==== Colors ====
m1c = '#00ee00'
bgc = '#222222'
dbg = '#000000'
fgc = '#111111'
aqua = '#00FFFF'

 
gui.tk_setPalette(background=bgc, foreground=aqua, activeBackground=fgc,activeForeground=bgc, highlightColor=aqua, highlightBackground=aqua)
 
# ==== Labels ====
LPortScanner = Label(gui, text = "Port Scanner",  font=("Helvetica", 24))
LPortScanner.place(x = 200, y = 35)
 
LIP = Label(gui, text = "IP Target : ", font=("Helvetica", 12))
LIP.place(x = 40, y = 150)

img = ImageTk.PhotoImage(Image.open("logonmap.png"))

LImage = Label(image = img)
LImage.place(x=15, y=30, width=157, height=90)
EntIP = Entry(gui, font=("Helvetica", 12))
EntIP.place(x = 190, y = 150)
EntIP.insert(0, "localhost")
 
LPort = Label(gui, text = "Ports Range : ", font=("Helvetica", 12))
LPort.place(x = 40, y = 200)
 
EntminPort = Entry(gui, text = "1", font=("Helvetica", 12))
EntminPort.place(x = 190, y = 200)
EntminPort.insert(0, "1")
 
EntmaxPort = Entry(gui, text = "1024", font=("Helvetica", 12))
EntmaxPort.place(x = 383, y = 200)
EntmaxPort.insert(0, "1024")
 
LResult = Label(gui, text = "Results  : ", font=("Helvetica", 12))
LResult.place(x = 340, y = 330)
L27 = Label(gui, text = "[ ... ]", font=("Helvetica", 11))
L27.place(x = 393, y = 330)
 
# ==== Ports list ====
frame = Frame(gui)
frame.place(x = 40, y = 270, width = 288, height = 296)
listbox = Listbox(frame, width = 59, height = 10, font=("Helvetica", 11))
listbox.place(x = 0, y = 0)
listbox.bind('<<ListboxSelect>>')
scrollbar = Scrollbar(frame)
scrollbar.pack(side=RIGHT, fill=Y)
listbox.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)
 
# ==== Buttons / Scans ====
BScan = Button(gui, text = "Scan", command=startScan)
BScan.place(x = 340, y = 270, width = 102, height=30)
BClear = Button(gui, text = "Clear", command=delete)
BClear.place(x = 470, y = 270, width = 99, height=30)

# === Buttons / clear ===

 
# ==== Start GUI ====
gui.mainloop()